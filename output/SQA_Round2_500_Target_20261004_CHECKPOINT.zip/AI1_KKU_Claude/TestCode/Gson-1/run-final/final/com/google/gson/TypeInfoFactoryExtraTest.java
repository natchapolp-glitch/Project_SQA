package com.google.gson;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.lang.reflect.Field;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.junit.Test;

public class TypeInfoFactoryExtraTest {

  static class GenericArrayHolder<T> {
    T[] arrayValue;
  }

  static class WildcardHolder<T> {
    List<? extends Number> wildcardList;
  }

  private Type parameterizedType(final Type rawType, final Type... args) {
    return new ParameterizedType() {
      @Override
      public Type[] getActualTypeArguments() {
        return args;
      }

      @Override
      public Type getRawType() {
        return rawType;
      }

      @Override
      public Type getOwnerType() {
        return null;
      }
    };
  }

  @Test
  public void testGetTypeInfoForField_genericArrayResolvedToObjectArray() throws Exception {
    Field field = GenericArrayHolder.class.getDeclaredField("arrayValue");
    Type parameterizedHolder = parameterizedType(GenericArrayHolder.class, String.class);
    TypeInfo info = TypeInfoFactory.getTypeInfoForField(field, parameterizedHolder);
    assertEquals(String[].class, info.getRawClass());
  }

  @Test
  public void testGetTypeInfoForField_wildcardTypeResolvesToUpperBound() throws Exception {
    Field field = WildcardHolder.class.getDeclaredField("wildcardList");
    TypeInfo info = TypeInfoFactory.getTypeInfoForField(field, WildcardHolder.class);
    assertEquals(List.class, info.getRawClass());
    assertTrue(info.getActualType() instanceof ParameterizedType);
    ParameterizedType pt = (ParameterizedType) info.getActualType();
    assertEquals(Number.class, pt.getActualTypeArguments()[0]);
  }

  @Test
  public void testGetTypeInfoForArray_genericArrayType() throws Exception {
    Field field = TypeInfoFactoryTest.Container.class.getDeclaredField("genericArray");
    Type genericArrayType = field.getGenericType();
    assertTrue(genericArrayType instanceof GenericArrayType);
    TypeInfoArray info = TypeInfoFactory.getTypeInfoForArray(genericArrayType);
    assertEquals(List.class, info.getComponentRawType());
  }

  @Test
  public void testGetTypeInfoForField_nestedParameterizedType() throws Exception {
    Field field = TypeInfoFactoryTest.Holder.class.getDeclaredField("listValue");
    Type innerParameterized = parameterizedType(List.class, Integer.class);
    Type parameterizedHolder = parameterizedType(TypeInfoFactoryTest.Holder.class, innerParameterized);
    TypeInfo info = TypeInfoFactory.getTypeInfoForField(field, parameterizedHolder);
    assertEquals(List.class, info.getRawClass());
    assertTrue(info.getActualType() instanceof ParameterizedType);
    ParameterizedType pt = (ParameterizedType) info.getActualType();
    assertTrue(pt.getActualTypeArguments()[0] instanceof ParameterizedType);
  }
}
