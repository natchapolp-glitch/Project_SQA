package org.apache.commons.csv;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.StringReader;
import org.junit.Test;

public class ExtendedBufferedReaderAdditionalTest {

    @Test
    public void testReadArrayEof() throws IOException {
        StringReader reader = new StringReader("");
        ExtendedBufferedReader ebr = new ExtendedBufferedReader(reader);

        char[] buf = new char[5];
        int len = ebr.read(buf, 0, 5);
        assertEquals(-1, len);
        assertEquals(ExtendedBufferedReader.END_OF_STREAM, ebr.readAgain());
    }
}
