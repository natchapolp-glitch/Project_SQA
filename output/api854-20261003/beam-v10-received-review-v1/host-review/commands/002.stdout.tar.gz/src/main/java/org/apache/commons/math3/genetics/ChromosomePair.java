/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.math3.genetics;

/**
 * A pair of {@link Chromosome} objects.
 * @since 2.0
 *
 * @version $Id$
 */
public class ChromosomePair {
    /** the first chromosome in the pair. */
    private final Chromosome first;

    /** the second chromosome in the pair. */
    private final Chromosome second;

    /**
     * Create a chromosome pair.
     *
     * @param c1 the first chromosome.
     * @param c2 the second chromosome.
     */
    public ChromosomePair(final Chromosome c1, final Chromosome c2) {
        super();
        first = c1;
        second = c2;
    }

    /**
     * Access the first chromosome.
     *
     * @return the first chromosome.
     */
    public Chromosome getFirst() {
        return first;
    }

    /**
     * Access the second chromosome.
     *
     * @return the second chromosome.
     */
    public Chromosome getSecond() {
        return second;
    }

    @Override
    public String toString() {
        return String.format("(%s,%s)", getFirst(), getSecond());
    }
}
