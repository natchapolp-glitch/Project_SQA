package org.apache.commons.compress.archivers.tar;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import org.junit.Test;

public class TarArchiveOutputStreamExtraTest {

    @Test
    public void finishWritesTwoEOFRecords() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
        TarArchiveEntry entry = new TarArchiveEntry("file.txt");
        entry.setSize(0);
        tos.putArchiveEntry(entry);
        tos.closeArchiveEntry();
        tos.finish();
        tos.flush();

        int recordSize = tos.getRecordSize();
        byte[] result = bos.toByteArray();
        assertTrue(result.length >= 2 * recordSize);
        byte[] lastTwoRecords = new byte[2 * recordSize];
        System.arraycopy(result, result.length - lastTwoRecords.length, lastTwoRecords, 0, lastTwoRecords.length);
        for (byte b : lastTwoRecords) {
            assertEquals(0, b);
        }
        bos.close();
    }

    @Test
    public void closeIsIdempotent() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
        TarArchiveEntry entry = new TarArchiveEntry("file.txt");
        entry.setSize(0);
        tos.putArchiveEntry(entry);
        tos.closeArchiveEntry();
        tos.close();
        // Calling close again must not throw
        tos.close();
    }

    @Test
    public void createArchiveEntryFromFileUsesGivenName() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
        File tempFile = File.createTempFile("tarTest", ".txt");
        tempFile.deleteOnExit();
        try {
            TarArchiveEntry entry = (TarArchiveEntry) tos.createArchiveEntry(tempFile, "renamed.txt");
            assertEquals("renamed.txt", entry.getName());
        } finally {
            tempFile.delete();
            tos.close();
        }
    }

    @Test
    public void writeAcrossMultipleRecordsAssemblesProperly() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        TarArchiveOutputStream tos = new TarArchiveOutputStream(bos);
        int recordSize = tos.getRecordSize();
        int contentSize = recordSize + 100;
        byte[] content = new byte[contentSize];
        for (int i = 0; i < contentSize; i++) {
            content[i] = (byte) (i % 256);
        }
        TarArchiveEntry entry = new TarArchiveEntry("big.txt");
        entry.setSize(contentSize);
        tos.putArchiveEntry(entry);
        // write in small chunks to exercise assembly buffer logic
        int chunkSize = 37;
        int offset = 0;
        while (offset < contentSize) {
            int toWrite = Math.min(chunkSize, contentSize - offset);
            tos.write(content, offset, toWrite);
            offset += toWrite;
        }
        tos.closeArchiveEntry();
        tos.close();

        TarArchiveInputStream tis = new TarArchiveInputStream(new ByteArrayInputStream(bos.toByteArray()));
        TarArchiveEntry readEntry = tis.getNextTarEntry();
        assertEquals("big.txt", readEntry.getName());
        assertEquals(contentSize, readEntry.getSize());
        byte[] readBuf = new byte[contentSize];
        int totalRead = 0;
        int r;
        while (totalRead < contentSize && (r = tis.read(readBuf, totalRead, contentSize - totalRead)) != -1) {
            totalRead += r;
        }
        assertEquals(contentSize, totalRead);
        for (int i = 0; i < contentSize; i++) {
            assertEquals(content[i], readBuf[i]);
        }
        tis.close();
    }
}
