import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
public class GeneratedStudyTest {
  @Test(timeout=10000)
  public void generated1() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseObjectLiteral", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{-0.61049100893172659, 0.93050221412222234, 0.84795280335358858, -0.065722643606052067, 0.3269412890601211, -0.57095406052406394, -0.55660750094751865, -0.42295513323748768, 0.384845491990635, -0.57524646328333784, 0.94221190270754729, -0.85928903139767154, -0.61342674253781793, -0.82227286033016833, 0.53978387322020516, -0.26697005045993127, -0.056635472382933427, -0.34794346632331141, 0.2748538373588767, -0.19221133854535144, -0.58346459175796883}));
  }
  @Test(timeout=10000)
  public void generated2() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "inferTemplateTypesFromParameters", "com.google.javascript.rhino.jstype.FunctionType,com.google.javascript.rhino.Node", new double[]{0.36691307832350173, -0.98810455272076059, -0.83187732002215831, -0.93601413703448788, -0.30846918323353778, 0.89219684455009607, 0.75141415658992283, 0.67715127493774241, -0.76225586718579907, 0.41144902422832419, 0.5489576251125674, 0.61851368040772048, 0.58446834441411943, -0.71936832836615805, -0.64233525210009201, 0.58512023390622536, 0.47643327613055031, 0.78489882569515235, -0.10704748369600048, 0.77914445055590686, -0.72118204711048595}));
  }
  @Test(timeout=10000)
  public void generated3() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseGetElem", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.11494236361125787, -0.77372512305190511, 0.653686627674815, 0.73638090042259496, 0.70270018815450008, 0.53469862141164493, -0.51550320806685601, -0.41214996310872776, -0.89803007832073756, 0.57086755998041738, 0.71950204939621587, 0.87315269222121739, 0.20108144095977654, 0.5980109872017132, 0.69110682663567591, -0.7585478021062293, -0.86328557024709207, 0.75295676500355846, 0.94112295846847682, 0.43233990234790598, 0.23898751718308486}));
  }
  @Test(timeout=10000)
  public void generated4() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseShortCircuitingBinOp", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean", new double[]{0.17794965586031175, 0.76774328747836562, -0.12325744222066581, 0.83890797734224565, -0.93047816848165188, 0.14456609686776689, 0.55555428633830739, -0.012570542900460335, 0.6584849005482285, 0.96264560621563811, 0.67584522685185422, -0.042805948791273307, 0.38253983500007438, 0.74248431823911121, 0.24640617566158651, -0.90716706590137108, -0.58786880977873035, 0.22120297208654516, -0.76913764025865761, -0.68201901704743073, 0.9438754812895358, 0.0038930259241551912, 0.97762981352974632, 0.67519923780170732}));
  }
  @Test(timeout=10000)
  public void generated5() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseShortCircuitingBinOp", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope,boolean", new double[]{0.54193925884064509, -0.63130770392729896, 0.049962903853019158, 0.73826968840366591, 0.34985936671928797, -0.21633232256109958, -0.62211246129222908, 0.89138900046578184, 0.53648008546532622, 0.37779173320688852, -0.4880470136791526, -0.5192224365250413, 0.74449624476667586, 0.66263899573395202, 0.66452743886009769, -0.39154945881626602, 0.43128076570015517, 0.62932848047225609, 0.79222343410591334, 0.42607748466032369, -0.86912259745596199, -0.89359722826003773, -0.43532870851728633, 0.5969027960228479}));
  }
  @Test(timeout=10000)
  public void generated6() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "maybeResolveTemplateTypeFromNodes", "java.util.Iterator,java.util.Iterator,java.util.Map,java.util.Set", new double[]{-0.54375214136609373, -0.46361075965240528, -0.92367500129458158, 0.96017667012641694, -0.4773874618165006, -0.62097119989661032, 0.42614578326092634, -0.81436305415761168, 0.60767988163588127, 0.43805415735597597, -0.92204377773323465, 0.57703851657211969, -0.56872134998529167, -0.81136689263443462, 0.50386900054603889, 0.86286969366685673, -0.27620531769701828, -0.42063108662543991, 0.0045781888949125715, 0.56884129048090082, 0.94489123185904522, 0.35830014968953439, -0.23385824827960988, -0.065286313027205001, 0.73567766529671919, -0.46188773173122044, -0.24767295011177537}));
  }
  @Test(timeout=10000)
  public void generated7() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "ensurePropertyDefined", "com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType", new double[]{0.67318586056721852, 0.5934339983341641, -0.72129534681475183, 0.77247511211051978, 0.95571409580348754, 0.60851211527398585, 0.85998926260855346, -0.37569062893746019, 0.58431216042043532, -0.11931584342079171, -0.95864665286489115, 0.11207992996941663, -0.77185690443305943, 0.75904533538856023, 0.45191120307341537, 0.044316557040686044, 0.72210176964182682, 0.84970251229997351, -0.45584484936465031, 0.15360540009902546, 0.54740425282301874}));
  }
  @Test(timeout=10000)
  public void generated8() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "branchedFlowThrough", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.36514148413556202, -0.55139721195287983, -0.77124325186771614, 0.9599936390661008, -0.50486766041471176, -0.75220590649619545, 0.68386405690577989, -0.29677427159536163, -0.040898426562357759, 0.56579248385193126, 0.48191282270330582, 0.87294401255109078, 0.86414162428013386, 0.74174779558000337, -0.54173292633315606, 0.39251579759709321, -0.86754323563953317, -0.54161929323622982, -0.24890985127719834, 0.52904466726547228, -0.96823638530775424}));
  }
  @Test(timeout=10000)
  public void generated9() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverse", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{-0.63938171428073587, -0.026616997661357944, -0.59074207851216842, -0.48874548906889981, 0.34963441136324414, 0.48152828104641698, -0.74410725308110792, -0.20588847772723096, 0.43736459054596799, 0.87491916472207465, -0.78547364810181963, 0.82235317398983909, -0.73922189697375296, 0.48754475534920139, -0.31786003657328354, 1.8753354709133419e-05, 0.73028272401272076, -0.72332013927301153, -0.97019736906559606, -0.10314850912325979, -0.52013038193896488}));
  }
  @Test(timeout=10000)
  public void generated10() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseHook", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.069871033405986216, -0.99910392877351017, 0.52938123316885211, -0.72287649519215735, 0.58540567154050427, -0.2552904568592711, 0.36353144653593206, -0.14038097296058405, -0.8965158576309582, 0.94446775717526954, 0.64359852585334165, -0.16077208704091217, 0.14459692070075025, -0.98682871279350803, 0.18256162746995397, -0.98940455622569146, -0.86870780080231436, 0.26744455310514015, -0.69675432342278798, 0.22341924789928269, -0.48839531152945348}));
  }
  @Test(timeout=10000)
  public void generated11() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "isAddedAsNumber", "com.google.javascript.rhino.jstype.JSType", new double[]{-0.75894968997886036, 0.24244475727410197, -0.9601709808894523, 0.73613955612423121, -0.66077431416675192, 0.19709687534252884, -0.625600106524977, -0.37299189265428412, -0.7569194436413047, -0.095519049716676019, 0.65905629144481259, 0.6997651108290539, 0.83374793552631976, -0.54047378818764469, 0.57396842836566653, -0.41585977460827195, 0.051261417846185653, -0.2947478891557751}));
  }
  @Test(timeout=10000)
  public void generated12() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "ensurePropertyDefined", "com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType", new double[]{0.15611653735795827, 0.72641344688554632, 0.82479522583486653, -0.10902312064920117, 0.77461162984845555, 0.14796469104505627, 0.28971422027198623, 0.34503465804094424, -0.16822435093790067, -0.94448610931712906, -0.61093611522479141, -0.84704650246574431, -0.67100632960499462, 0.44495896461810336, -0.38345112322299624, 0.0030104471394956089, -0.99258285524268386, -0.70155894524125895, -0.15076475525979549, -0.09193908829600117, -0.025887227967772652}));
  }
  @Test(timeout=10000)
  public void generated13() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverse", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{-0.59016432835204968, 0.33557859763182085, 0.43092391187212131, -0.68006976599206137, -0.95349274194400491, 0.7191650224970334, -0.79591913669176595, 0.95298602841417224, 0.09470784340200944, -0.89329850706501013, -0.57951905908098555, -0.45486811979836594, 0.84383141782599447, -0.89068741186895561, 0.9546620548011695, 0.61092975444770459, -0.68229236633603829, 0.12747302748573519, -0.82798266635542639, -0.766571282822196, -0.67705825056464142}));
  }
  @Test(timeout=10000)
  public void generated14() {
    assertEquals("value:com.google.javascript.rhino.jstype.BooleanLiteralSet:Qk9USA==", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "", "getBooleanOutcomes", "com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean", new double[]{-0.81339680005473358, -0.43742560007501474, 0.58041668579491046, 0.77214945308906491, -0.6148477673658086, -0.8892078564593433, -0.1515208106682997, -0.65330218273645801, -0.931403707953677}));
  }
  @Test(timeout=10000)
  public void generated15() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "createInitialEstimateLattice", "", new double[]{0.042830027195691622, -0.60205608842406555, -0.45731990939349343, -0.98431711098953611, -0.15084146858395875, 0.29462850722895428, 0.30841947478212983, 0.80812243148762897, -0.012061964472882103, 0.62103773322496392, 0.75602974118497412, -0.31224685900030269, -0.30336053981033206, 0.76429619501299517, 0.15895834333980297}));
  }
  @Test(timeout=10000)
  public void generated16() {
    assertEquals("value:com.google.javascript.rhino.jstype.BooleanLiteralSet:Qk9USA==", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "", "getBooleanOutcomes", "com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean", new double[]{0.64355308873543815, -0.2793168616095989, 0.99040291043164874, 0.7558995915328659, -0.71458184186664875, 0.6262800803881432, 0.9116127969416532, 0.10259585162622642, -0.038176838894999454}));
  }
  @Test(timeout=10000)
  public void generated17() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseArrayLiteral", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.96981792601800754, -0.89859859257254771, 0.41201986088461195, -0.081949953951679255, 0.13316063251359611, 0.6060473854464048, -0.58105126364615556, 0.77212538167497824, -0.59361516364473732, -0.87116233984253344, 0.3760350007190818, 0.44388502727169965, -0.94815653335540118, 0.29796888132953958, 0.88413741970627635, -0.40851444961398942, -0.88634418924470304, -0.437794709871836, -0.50121652275307604, -0.22962996676154535, 0.54374206746759768}));
  }
  @Test(timeout=10000)
  public void generated18() {
    assertEquals("value:com.google.javascript.rhino.jstype.BooleanLiteralSet:RkFMU0U=", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "", "getBooleanOutcomes", "com.google.javascript.rhino.jstype.BooleanLiteralSet,com.google.javascript.rhino.jstype.BooleanLiteralSet,boolean", new double[]{0.0084148402078365603, -0.26374507572674744, -0.94238628523251045, -0.62629965652696451, -0.86286763272195555, -0.90847011531987332, 0.37188892499348225, -0.62774292206573268, -0.91315109769332481}));
  }
  @Test(timeout=10000)
  public void generated19() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "<init>", "", new double[]{-0.97235105037238068, 0.55989952715179925, 0.17612192094471602, -0.76031241582984266, -0.8020841167045869, 0.93172813627794482, -0.50072051182482369, 0.38535634244655204, 0.025903243357031647, 0.82984940156138043, -0.055990859830866491, 0.99936596585128989, 0.48520021253197254, 0.98559917020817811, 0.76274904038519709}));
  }
  @Test(timeout=10000)
  public void generated20() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseAnd", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.90074795770147431, 0.81529496134017787, -0.83481134436169424, 0.5867172147967743, -0.43742793859918705, 0.071479725058119614, 0.9500775907157446, 0.22561009383595065, 0.55084963554361699, -0.79622159088931177, -0.20562739335646119, -0.48346846472134231, -0.3559945767108883, -0.44849882631549431, -0.23595219394253242, -0.8529744357255884, 0.34791487833460111, -0.026075405764949267, 0.43430746649313057, -0.93036091706647106, -0.99246156231533056}));
  }
  @Test(timeout=10000)
  public void generated21() {
    assertEquals("void", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "", "inferPropertyTypesToMatchConstraint", "com.google.javascript.rhino.jstype.JSType,com.google.javascript.rhino.jstype.JSType", new double[]{0.4478881761137985, -0.20636544156033554, -0.28127420078007548, 0.45695874201916276, -0.65975194753691535, 0.99437158546539228}));
  }
  @Test(timeout=10000)
  public void generated22() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "getPropertyType", "com.google.javascript.rhino.jstype.JSType,java.lang.String,com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{0.69278460013505327, 0.88432488208908699, 0.92176799388544062, 0.852287115873684, -0.17705012664327868, -0.57339694265060914, 0.90894094715847817, 0.18319161303960074, -0.17204692158868173, 0.35712901804935404, 0.25435968321995217, 0.91067289166471466, -0.22122580470790609, -0.047875461312506085, -0.60310657868636453, 0.52275424840769991, 0.35259371084089386, -0.74248523741839101, -0.11132140320868555, 0.8524152396773319, -0.99938426938464775, 0.64960989023584248, 0.65914432948440749, 0.34459908240281023, -0.82776477859958342, 0.31449935463165013, 0.94507919509921323}));
  }
  @Test(timeout=10000)
  public void generated23() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "", "resolvedTemplateType", "java.util.Map,com.google.javascript.rhino.jstype.TemplateType,com.google.javascript.rhino.jstype.JSType", new double[]{0.65251098941604213, 0.93915690427939547, 0.35411152273613533, 0.58518056781737249, -0.6431320114858905, 0.70899061608734715, -0.48176805223323083, 0.72036090992559876, 0.80813903868619752}));
  }
  @Test(timeout=10000)
  public void generated24() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseAnd", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{-0.7825610728112451, 0.98573882257946766, -0.13948382108776891, 0.82999152122831887, -0.69926524406312063, -0.28931875329113588, -0.97661425788473299, -0.28950883194975119, 0.51772905251109291, -0.28344361852140709, -0.38294757430655713, -0.078851489742730818, 0.99007410011670305, 0.73055412183357249, -0.22237886890277658, 0.52067641914773799, -0.24127866596620495, 0.73718949158240177, 0.72823683110530801, 0.37074693138826231, 0.89486509271097781}));
  }
  @Test(timeout=10000)
  public void generated25() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "inferTemplatedTypesForCall", "com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.FunctionType", new double[]{-0.1672823587688439, 0.086759926429468059, -0.36897036541467698, 0.081298404845621564, 0.90191992845489066, 0.69320543227765419, 0.15295368326416647, 0.76200096417307606, -0.36281353459172028, 0.35437045165855485, -0.33864255563557566, 0.55280924022252442, 0.64081577863804728, -0.64930302320567224, -0.51128700183492692, -0.1499146701672156, -0.58118569294126865, -0.22689453301427842, 0.75794675496774189, -0.83824590309498404, 0.4418531359703024}));
  }
  @Test(timeout=10000)
  public void generated26() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "maybeResolveTemplateTypeFromNodes", "java.util.Iterator,java.util.Iterator,java.util.Map,java.util.Set", new double[]{0.77274663540471589, -0.75804345512580218, -0.62389427385427898, -0.93673522242251206, -0.88791084126787334, 0.92863965693182737, 0.445775514100887, -0.85662379189128601, -0.20637844346103718, 0.43622124364820447, -0.54199708136410663, 0.51672940408985668, -0.84412202373341549, 0.97589687925628033, 0.14533466498605718, 0.84981769679998242, -0.89335766750650736, 0.60801600505934217, 0.43504499633400995, 0.71515842290950804, 0.81923924976941231, -0.10855903350714136, 0.95222940110857057, 0.10007459194688617, 0.71883501973574404, -0.65637517448116145, -0.73811536924711896}));
  }
  @Test(timeout=10000)
  public void generated27() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "getNativeType", "com.google.javascript.rhino.jstype.JSTypeNative", new double[]{0.81668580608837016, 0.75666647332629933, 0.43512033710931974, -0.80740420556885972, 0.85347811780565719, -0.97041434598809229, -0.88600949995128331, 0.67941803762972919, -0.40883132678981515, 0.043916799507252025, 0.87904576489835162, -0.073200104875258409, -0.10095682568154118, -0.1905146236377302, -0.69406695270740193, 0.63307357644682494, 0.79055518886882226, 0.7836001188738122}));
  }
  @Test(timeout=10000)
  public void generated28() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "traverseCall", "com.google.javascript.rhino.Node,com.google.javascript.jscomp.type.FlowScope", new double[]{-0.034919159768281638, -0.76673819568983514, -0.5428593672215456, -0.73475038345652899, -0.72948753399684829, -0.25827737611025792, -0.16567114051155718, -0.37167324575801741, 0.40552324688925734, -0.56009971526736835, 0.34011830749678529, 0.82340199946923542, 0.79059028710470236, 0.059978329309360312, -0.83551487104520472, -0.99730609368625944, 0.81886722688520752, 0.6157327946386737, 0.25726051300860164, -0.50071055526841191, 0.13382547826287206}));
  }
  @Test(timeout=10000)
  public void generated29() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "createEntryLattice", "", new double[]{0.20810475058746114, 0.92334957979425125, -0.22126005024345119, -0.88248600149339884, -0.96888394695115343, 0.10078994453738166, -0.82075962201775288, -0.13919896623564343, -0.74372967214784858, 0.0095609330835075834, -0.66338945481063227, 0.75419670949190976, -0.091315616501317587, 0.91340164018861714, -0.85711213322980351}));
  }
  @Test(timeout=10000)
  public void generated30() {
    assertEquals("exception:java.lang.NullPointerException", SqaProbe.observe("com.google.javascript.jscomp.TypeInference", "com.google.javascript.jscomp.AbstractCompiler,com.google.javascript.jscomp.ControlFlowGraph,com.google.javascript.jscomp.type.ReverseAbstractInterpreter,com.google.javascript.jscomp.Scope,java.util.Map", "updateScopeForTypeChange", "com.google.javascript.jscomp.type.FlowScope,com.google.javascript.rhino.Node,com.google.javascript.rhino.jstype.JSType,com.google.javascript.rhino.jstype.JSType", new double[]{-0.28451817277135061, -0.054129963461504005, -0.81835842544245252, 0.7004888648958485, 0.86049877254652785, -0.20887637819990545, -0.55689445141143334, 0.82848421542069217, -0.52440913975149694, 0.55142147811974818, -0.94349495940731831, 0.93798374750554059, 0.61830970244620209, -0.81774204006054418, -0.43538685704166125, -0.57397421616618804, -0.63509639422755293, -0.82001055818414659, -0.90784812165464013, 0.052660587903260447, -0.87347678282249919, 0.91484300069757252, -0.96450854593296653, -0.34873263685576528, 0.89450786745097299, -0.76140838220309859, 0.45176517926470483}));
  }

/** Fixed-revision observations for explicitly supported, deterministic Java APIs.
 * No buggy source, patch, or triggering test is used during input generation.
 * The same source is packaged with the generated JUnit suite.
 */
public static final class SqaProbe {
    private static final String[] STRINGS = {
        "", "0", "1", "-1", "null", "true", "false", "abc", "ABC", " ",
        "0x0", "0x1", "0xFFFFFFFF", "1.0", "1e3", "NaN", "Infinity",
        "{}", "[]", "[1]", "{\"a\":1}", "a=b", "--help", "-x", "a,b",
        "1970-01-01", "a\\nb", "a\nb", "a\tb", "\u0e17\u0e14\u0e2a\u0e2d\u0e1a"
    };
    private static final long[] NUMBERS = {0, 1, -1, 2, -2, 10, -10, 127, 128,
        255, 256, 32767, -32768, Integer.MAX_VALUE, Integer.MIN_VALUE};

    private SqaProbe() { }

    private static String quote(String value) {
        StringBuilder out = new StringBuilder("\"");
        for (char c : value.toCharArray()) {
            if (c == '"' || c == '\\') out.append('\\').append(c);
            else if (c < 32) out.append(String.format("\\u%04x", (int)c));
            else out.append(c);
        }
        return out.append('"').toString();
    }

    private static String typeNames(Class<?>[] types) {
        List<String> names = new ArrayList<String>();
        for (Class<?> type : types) names.add(type.getName());
        return String.join(",", names);
    }

    private static boolean scalar(Class<?> type) {
        return type.isPrimitive() || type == String.class || type == Boolean.class
            || type == Character.class || type == Byte.class || type == Short.class
            || type == Integer.class || type == Long.class || type == Float.class
            || type == Double.class || type.isEnum();
    }

    private static boolean supported(Class<?> type) {
        return scalar(type) || (type.isArray() && scalar(type.getComponentType()));
    }

    private static boolean supportedParameters(Class<?>[] types) {
        if (types.length > 6) return false;
        for (Class<?> type : types) if (type == void.class) return false;
        return true;
    }

    private static Class<?> type(String name) throws ClassNotFoundException {
        if (name.equals("boolean")) return boolean.class;
        if (name.equals("byte")) return byte.class;
        if (name.equals("short")) return short.class;
        if (name.equals("int")) return int.class;
        if (name.equals("long")) return long.class;
        if (name.equals("float")) return float.class;
        if (name.equals("double")) return double.class;
        if (name.equals("char")) return char.class;
        return Class.forName(name);
    }

    private static Class<?>[] types(String names) throws ClassNotFoundException {
        if (names.length() == 0) return new Class<?>[0];
        String[] split = names.split(",", -1);
        Class<?>[] result = new Class<?>[split.length];
        for (int i = 0; i < split.length; i++) result[i] = type(split[i]);
        return result;
    }

    private static int bucket(double coordinate, int size) {
        double unit = Math.max(0, Math.min(1, (coordinate + 1) / 2));
        return Math.min(size - 1, (int)(unit * size));
    }

    private static Object argument(Class<?> type, double a, double b, double c) {
        return argument(type, a, b, c, 0);
    }

    private static Object argument(Class<?> type, double a, double b, double c, int depth) {
        if (depth > 2) return null;
        if (type.isArray()) {
            int length = bucket(c, 5);
            Object array = Array.newInstance(type.getComponentType(), length);
            for (int i = 0; i < length; i++) {
                Array.set(array, i, argument(type.getComponentType(),
                    Math.max(-1, Math.min(1, a + i * 0.17)), b, c, depth + 1));
            }
            return array;
        }
        if (!type.isPrimitive() && a < -0.96) return null;
        if (type == String.class) {
            int selection = bucket(a, STRINGS.length + 4);
            if (selection < STRINGS.length) return STRINGS[selection];
            int length = bucket(c, 33);
            char character = "0123456789abcdefXYZ +-_.".charAt(bucket(b, 23));
            char[] value = new char[length];
            Arrays.fill(value, character);
            return new String(value);
        }
        if (type == boolean.class || type == Boolean.class) return a >= 0;
        if (type == char.class || type == Character.class) return (char)bucket(a, 128);
        if (type.isEnum()) {
            Object[] values = type.getEnumConstants();
            return values.length == 0 ? null : values[bucket(a, values.length)];
        }
        long integer = b < 0 ? NUMBERS[bucket(a, NUMBERS.length)] : Math.round(a * 10000);
        if (type == byte.class || type == Byte.class) return (byte)integer;
        if (type == short.class || type == Short.class) return (short)integer;
        if (type == int.class || type == Integer.class) return (int)integer;
        if (type == long.class || type == Long.class) return integer;
        double real = b < 0 ? integer : a * 1000;
        if (type == float.class || type == Float.class) return (float)real;
        if (type == double.class || type == Double.class) return real;
        if (type == Number.class) return Double.valueOf(real);
        if (type == Object.class) return b < 0 ? STRINGS[bucket(a, STRINGS.length)] : Long.valueOf(integer);
        if (type == java.util.Date.class) return new java.util.Date(integer);
        if (type == java.util.List.class || type == java.util.Collection.class || type == Iterable.class)
            return new java.util.ArrayList<Object>();
        if (type == java.util.Set.class) return new java.util.HashSet<Object>();
        if (type == java.util.Map.class) return new java.util.HashMap<Object,Object>();
        if (!type.isInterface() && !Modifier.isAbstract(type.getModifiers()) && !type.getName().startsWith("java.")) {
            Constructor<?>[] constructors = type.getDeclaredConstructors();
            Arrays.sort(constructors, new Comparator<Constructor<?>>() {
                public int compare(Constructor<?> left, Constructor<?> right) {
                    int count = left.getParameterCount() - right.getParameterCount();
                    return count != 0 ? count : left.toString().compareTo(right.toString());
                }
            });
            for (Constructor<?> constructor : constructors) {
                if (constructor.getParameterCount() > 3) continue;
                try {
                    constructor.setAccessible(true);
                    Class<?>[] parameters = constructor.getParameterTypes();
                    Object[] values = new Object[parameters.length];
                    for (int i = 0; i < values.length; i++) values[i] = argument(parameters[i], a, b, c, depth + 1);
                    return constructor.newInstance(values);
                } catch (ReflectiveOperationException error) {
                    // Failed fixture construction yields an explicit null boundary input.
                } catch (RuntimeException error) {
                    // Encapsulated/unconstructible fixture yields the same null boundary.
                }
            }
        }
        return null;
    }

    private static Object[] arguments(Class<?>[] types, double[] vector, int offset) {
        Object[] values = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            int start = offset + 3 * i;
            values[i] = argument(types[i], vector[start % vector.length],
                vector[(start + 1) % vector.length], vector[(start + 2) % vector.length]);
        }
        return values;
    }

    private static String value(Object value) {
        if (value == null) return "null";
        Class<?> type = value.getClass();
        if (type.isArray()) {
            StringBuilder out = new StringBuilder(type.getName()).append('[');
            int length = Array.getLength(value);
            if (length > 100000) throw new IllegalStateException("SQA_HARNESS oversized outcome");
            for (int i = 0; i < length; i++) out.append(value(Array.get(value, i))).append(';');
            return out.append(']').toString();
        }
        if (value instanceof Class) return "class:" + ((Class<?>)value).getName();
        if (!scalar(type) && !(value instanceof Number)) return "object-type:" + type.getName();
        String text = value instanceof Enum ? ((Enum<?>) value).name() : String.valueOf(value);
        return type.getName() + ":" + Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    private static String snapshot(String observed) {
        // JVM string constants are limited to 65,535 encoded bytes. Long exact
        // observations use a deterministic digest rather than enormous literals.
        if (observed.length() <= 16000) return observed;
        byte[] bytes = observed.getBytes(StandardCharsets.UTF_8);
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(bytes);
            StringBuilder hex = new StringBuilder();
            for (byte item : digest) hex.append(String.format("%02x", item & 255));
            return "sha256:" + hex + ":bytes:" + bytes.length;
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException("SQA_HARNESS SHA-256 unavailable", error);
        }
    }

    public static String observe(String className, String constructorTypes, String methodName,
                                 String methodTypes, double[] vector) {
        if (vector.length == 0) throw new IllegalArgumentException("SQA_HARNESS empty vector");
        try {
            Class<?> target = Class.forName(className);
            Class<?>[] ctorTypes = types(constructorTypes);
            Class<?>[] parameterTypes = types(methodTypes);
            Object receiver = null;
            Method method = null;
            if (!methodName.equals("<init>")) {
                Class<?> declaring = target;
                while (declaring != null) {
                    try { method = declaring.getDeclaredMethod(methodName, parameterTypes); break; }
                    catch (NoSuchMethodException missing) { declaring = declaring.getSuperclass(); }
                }
                if (method == null) throw new NoSuchMethodException(methodName);
                method.setAccessible(true);
            }
            if (method == null || !Modifier.isStatic(method.getModifiers())) {
                Constructor<?> ctor = target.getDeclaredConstructor(ctorTypes);
                ctor.setAccessible(true);
                receiver = ctor.newInstance(arguments(ctorTypes, vector, 0));
            }
            if (method == null) return "constructed:" + target.getName();
            Object result = method.invoke(receiver, arguments(parameterTypes, vector, ctorTypes.length * 3));
            return method.getReturnType() == void.class ? "void" : snapshot("value:" + value(result));
        } catch (InvocationTargetException error) {
            Throwable cause = error.getCause();
            if (cause instanceof VirtualMachineError || cause instanceof LinkageError || cause instanceof ThreadDeath)
                throw new IllegalStateException("SQA_HARNESS JVM failure", cause);
            return "exception:" + cause.getClass().getName();
        } catch (ReflectiveOperationException error) {
            throw new IllegalStateException("SQA_HARNESS reflection failure", error);
        } catch (LinkageError error) {
            throw new IllegalStateException("SQA_HARNESS linkage failure", error);
        }
    }

    private static String descriptor(String className, String ctor, String method, String params, int count) {
        return "{\"class\":" + quote(className) + ",\"constructor_types\":" + quote(ctor)
            + ",\"method\":" + quote(method) + ",\"parameter_types\":" + quote(params)
            + ",\"dimensions\":" + Math.max(3, count * 3) + "}";
    }

    private static void discover(String[] classes, List<String> fixtureClasses) {
        List<String> targets = new ArrayList<String>();
        List<String> errors = new ArrayList<String>();
        for (String className : classes) {
            try {
                Class<?> target = Class.forName(className, false, SqaProbe.class.getClassLoader());
                Class<?> receiverType = target;
                if (Modifier.isAbstract(target.getModifiers())) {
                    for (String name : fixtureClasses) {
                        try {
                            Class<?> candidate = Class.forName(name, false, SqaProbe.class.getClassLoader());
                            if (!Modifier.isAbstract(candidate.getModifiers()) && target.isAssignableFrom(candidate)
                                    && candidate.getDeclaredConstructors().length > 0) {
                                receiverType = candidate;
                                break;
                            }
                        } catch (ClassNotFoundException ignored) { } catch (LinkageError ignored) { }
                    }
                }
                List<Constructor<?>> constructors = new ArrayList<Constructor<?>>();
                if (!Modifier.isAbstract(receiverType.getModifiers()) && !receiverType.isEnum()) {
                    Constructor<?>[] all = receiverType.getDeclaredConstructors();
                    Arrays.sort(all, new Comparator<Constructor<?>>() {
                        public int compare(Constructor<?> a, Constructor<?> b) { return a.toString().compareTo(b.toString()); }
                    });
                    for (Constructor<?> ctor : all) {
                        if (supportedParameters(ctor.getParameterTypes())) constructors.add(ctor);
                    }
                    // Select a constructor before generating inputs; prefer the simplest fixture.
                    java.util.Collections.sort(constructors, new Comparator<Constructor<?>>() {
                        public int compare(Constructor<?> a, Constructor<?> b) { return a.getParameterCount() - b.getParameterCount(); }
                    });
                }
                Method[] methods = target.getDeclaredMethods();
                Arrays.sort(methods, new Comparator<Method>() {
                    public int compare(Method a, Method b) { return a.toString().compareTo(b.toString()); }
                });
                for (Method method : methods) {
                    if (method.isSynthetic() || method.getName().equals("main")
                        || method.isBridge() || !supportedParameters(method.getParameterTypes())
                        ) continue;
                    if (Modifier.isStatic(method.getModifiers())) {
                        targets.add(descriptor(className, "", method.getName(),
                            typeNames(method.getParameterTypes()), method.getParameterCount()));
                    } else if (!constructors.isEmpty()) {
                        Constructor<?> ctor = constructors.get(0);
                        targets.add(descriptor(receiverType.getName(), typeNames(ctor.getParameterTypes()), method.getName(),
                            typeNames(method.getParameterTypes()), ctor.getParameterCount() + method.getParameterCount()));
                    }
                }
                for (Constructor<?> ctor : constructors) {
                    if (ctor.getParameterCount() > 0)
                        targets.add(descriptor(receiverType.getName(), typeNames(ctor.getParameterTypes()), "<init>", "", ctor.getParameterCount()));
                }
            } catch (Throwable error) {
                if (error instanceof VirtualMachineError || error instanceof ThreadDeath) throw (Error)error;
                errors.add(quote(className + ":" + error.getClass().getName()));
            }
        }
        System.out.println("{\"targets\":[" + String.join(",", targets) + "],\"errors\":[" + String.join(",", errors) + "]}");
    }

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("discover")) {
            int start = 1;
            List<String> fixtures = new ArrayList<String>();
            if (args.length > 2 && args[1].equals("--fixtures")) {
                fixtures = Files.readAllLines(Paths.get(args[2]), StandardCharsets.UTF_8);
                start = 3;
            }
            discover(Arrays.copyOfRange(args, start, args.length), fixtures);
            return;
        }
        if (args.length != 6 || !args[0].equals("observe"))
            throw new IllegalArgumentException("SQA_HARNESS expected discover classes or observe class ctor method types vector");
        String[] pieces = args[5].split(",");
        double[] vector = new double[pieces.length];
        for (int i = 0; i < pieces.length; i++) {
            vector[i] = Double.parseDouble(pieces[i]);
            if (!Double.isFinite(vector[i]))
                throw new IllegalArgumentException("SQA_HARNESS nonfinite vector");
        }
        String outcome = observe(args[1], args[2], args[3], args[4], vector);
        System.out.println("SQA_RESULT:" + Base64.getEncoder().encodeToString(outcome.getBytes(StandardCharsets.UTF_8)));
    }
}
}
